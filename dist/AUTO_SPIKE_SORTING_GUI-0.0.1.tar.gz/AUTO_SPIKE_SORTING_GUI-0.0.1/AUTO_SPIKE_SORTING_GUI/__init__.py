#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr 12 11:11:32 2020

@author: anaiak
"""


from AUTO_SPIKE_SORTING_GUI.AUTO_SPIKE_SORTING_GUI import MyApp